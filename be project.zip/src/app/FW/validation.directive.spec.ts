import { ValidationDirective } from './validation.directive';

describe('ValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidationDirective();
    expect(directive).toBeTruthy();
  });
});
