

var instance = "http://localhost:8080";

export const api = {
  accountUrl:instance+"/DC/api/account/",
  adminUrl:instance+"/DC/api/admin/",
  facultyUrl:instance+"/DC/api/faculty/",
  studentUrl:instance+"/DC/api/student/",
  staffUrl:instance+"/DC/api/staff/",
  imageUrl:instance+"/DC/api/handler/",

  /*******Secrete********/
  passauth:'#mh07kr1305#'
}