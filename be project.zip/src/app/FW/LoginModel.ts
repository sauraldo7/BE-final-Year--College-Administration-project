export class loggedInUser{
    public DCUserId:number;
    public UserName:string;
    public UserId:number;
    public FullName:String;
    public InstituteName:String;
    public InstituteId:number;
    public Email:string;
    public UserType:string;
    public AuthToken:string;
}