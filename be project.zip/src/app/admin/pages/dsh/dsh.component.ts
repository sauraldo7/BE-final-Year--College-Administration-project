import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dsh',
  templateUrl: './dsh.component.html',
  styleUrls: ['./dsh.component.css']
})
export class DshComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
